<?php
require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';

function ScanWP_enqueue() {
    wp_enqueue_style('bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css');
    if($_SERVER['SERVER_NAME'] != 'localhost'){
      wp_enqueue_style('style', get_template_directory_uri() . '/style.min.css');
    } else{
      wp_enqueue_style('style', get_template_directory_uri() . '/style.css');
    }

    wp_enqueue_style('Open Sans', "https://fonts.googleapis.com/css?family=Open+Sans:300,400,700");
    wp_enqueue_style('fontawesome', 'https://use.fontawesome.com/releases/v5.2.0/css/all.css');
    wp_enqueue_script( 'bootstrapcdn', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js', array('jquery'), '', true );
}
add_action('wp_enqueue_scripts', 'ScanWP_enqueue');


add_theme_support( 'title-tag' );
add_theme_support( 'post-thumbnails' );
add_theme_support( 'custom-logo' );

register_nav_menus( array(
    'header' => 'Custom Primary Menu',
    'footer' => 'Custom Footer Menu',
  ) );

function ScanWP_widgets_init() {
  // register_sidebar( array(
  //   'name'          => 'Footer 1',
  //   'id'            => 'footer_1',
  //   'before_widget' => '<div id="%1$s" class="widget %2$s">',
  //   'after_widget'  => '</div>',
  //   'before_title'  => '<h4 class="ttl">',
  //   'after_title'   => '</h4>',
  // ) );
  // register_sidebar( array(
  //   'name'          => 'Footer 2',
  //   'id'            => 'footer_2',
  //   'before_widget' => '<div id="%1$s" class="widget %2$s">',
  //   'after_widget'  => '</div>',
  //   'before_title'  => '<h4 class="ttl">',
  //   'after_title'   => '</h4>',
  // ) );
  // register_sidebar( array(
  //   'name'          => 'Footer 3',
  //   'id'            => 'footer_3',
  //   'before_widget' => '<div id="%1$s" class="widget %2$s">',
  //   'after_widget'  => '</div>',
  //   'before_title'  => '<h4 class="ttl">',
  //   'after_title'   => '</h4>',
  // ) );
  // register_sidebar( array(
  //   'name'          => 'sidebar',
  //   'id'            => 'sidebar',
  //   'before_widget' => '<div id="%1$s" class="widget %2$s">',
  //   'after_widget'  => '</div>',
  //   'before_title'  => '<h4 class="ttl">',
  //   'after_title'   => '</h4>',
  // ) );
    register_sidebar( array(
    'name'          => esc_html__( 'Sidebar Post'),
    'id'            => 'sidebar-post',
    'description'   => esc_html__( 'Add widgets here.', 'cfv' ),
    'before_widget' => '<section id="%1$s" class="widget %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h2 class="widget-title">',
    'after_title'   => '</h2>',
  ) );
}
add_action( 'widgets_init', 'ScanWP_widgets_init' );


// DISPLAY CUSTOM LOGIN SCREEN //

function custom_logo() { ?>
<style type="text/css">
#login h1 a, .login h1 a {
background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/images/logo.svg); 
}
</style>
<?php }
add_action( 'login_enqueue_scripts', 'custom_logo' );


// DISPLAY ADMIN MESSAGE ON DASHBOARD //

add_action('wp_dashboard_setup', 'custom_dashboard_widgets'); 
function custom_dashboard_widgets() {
global $wp_meta_boxes;
wp_add_dashboard_widget('custom_contact_widget', 'Theme Support', 'custom_dashboard_contact');
}
function custom_dashboard_contact() {
// Widget Content Here
echo '    <p>Hey there!<br>
          <strong>Functionality in this theme:</strong><br>
          <ul>
            <li>- Create Blog Posts</li>
            <li>- Create Pages</li> 
            <li>- Create Pages</li>
            <li>- Assign two different templates to content pages (Full Width and Sidebar)</li>  
            <li>- Add Widgets to the Sidebar</li>   
            <li>- Author of the Blog Post is dynamically displayed in the sidebar of Blog posts. <br>
            (Data is taken out of the Users Account Informations)</li>   
            <li>- Featured Images of Posts and Pages are automatically displayed as a header image</li>   
            <li>- Add A Logo to the website - will be displayed in the navigation</li>               
            <li>- Fancy schmancy blog posts hover animations</li>   
          </ul>

          <strong>Needed Plugins</strong><br>
          <ul>
            <li>- Contact Form 7</li>
          </ul>          

          <a href="mailto:youremail@yourdomain.com">here</a>. </p>';
}
?>