<?php
/**
 * Template Name: Full Width Content Page
 */
?>

<?php get_header(); ?>
 
<div class="container">
	<div class="row ">
	   <div class="col-md-12">    
	      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<?php the_post_thumbnail() ?>
		    <div class="mt-3 mb-5 text-center">
		    <h1><?php the_title(); ?></h1>

			<hr>	
			</div>	
		<div class="row justify-content-md-center">
			<div class="col-md-10">
		         <div class="entry">
		            <?php the_content(); ?>
		         </div>
	     	</div>

       	</div>
	      <?php endwhile; endif; ?>
       </div>

	</div>
</div>
 
<?php get_footer(); ?>


