<?php if ( is_active_sidebar( 'sidebar-post' ) ) : ?>
		    <ul id="sidebar">
		<?php if ( 'post' === get_post_type() ) : ?>

			<div class="entry-meta">
			</div><!-- .entry-meta -->
			<div class="about-author">
				<img src="https://via.placeholder.com/150/cccccc/FFFFFF?Text=Down.com" class="author-img" alt=""><br>
				<!-- <?php the_author(); ?> -->
				<div class="mt-3 author-name">
					<?php $authorFirstName = the_author_meta('first_name'); echo $authorFirstName; ?>
					<?php $authorLastName = the_author_meta('last_name'); echo $authorLastName; ?>
				</div>

				<p>
					<?php $authorDesc = the_author_meta('description'); echo $authorDesc; ?>
				</p>
				<hr>
			</div>

		<?php endif; ?>

        <?php dynamic_sidebar( 'sidebar-post' ); ?>
    </ul>

<?php endif; ?>